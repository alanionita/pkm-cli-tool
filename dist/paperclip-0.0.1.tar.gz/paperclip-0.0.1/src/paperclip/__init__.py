"""
paperclip: A simple tool for creating .md notes for various use cases.
"""
